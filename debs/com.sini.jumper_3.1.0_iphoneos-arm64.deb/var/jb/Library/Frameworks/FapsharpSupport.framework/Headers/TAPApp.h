#import <Foundation/Foundation.h>

@interface TAPApp : NSObject <NSCoding>

@property (nonatomic, strong) NSString *bundleIdentifier;
@property (nonatomic, assign) BOOL isSystemApplication;
@property (nonatomic, assign) BOOL isUserApplication;
@property (nonatomic, assign) BOOL isHidden;
@property (nonatomic, strong) NSString *fastDisplayName;
@property (nonatomic, strong) NSString *nameToDisplay;

- (instancetype)initFromLSApplicationProxy:(id)proxy;
- (NSString *)bundleIdentifier;
- (BOOL)isSystemApplication;
- (BOOL)isUserApplication;
- (BOOL)isHidden;
- (NSString *)fastDisplayName;
- (NSString *)nameToDisplay;

@end
