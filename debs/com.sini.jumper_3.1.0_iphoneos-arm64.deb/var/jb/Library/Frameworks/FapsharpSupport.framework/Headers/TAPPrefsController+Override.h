#import <Foundation/Foundation.h>
#import "TAPPrefsController.h"

@interface TAPPrefsController (Override)
- (UIColor *)tap_primaryTintColor;
- (NSString *)tap_specifiersPlist;
- (NSString *)tap_identifier;
- (NSString *)tap_bundlePath;
- (NSString *)tap_nameString;
- (NSString *)tap_versionString;
- (BOOL)tap_useRightNavigationButtonMenu;
- (NSArray <UIAction *>*)tap_rightUIMenuActions;
- (NSArray <UIAlertAction *>*)tap_rightUIAlertActions;
- (BOOL)tap_respringAfterEnableSwitchToggle;
- (BOOL)tap_useCustomGroupHeaders;
- (UIImageView *)tap_logoView;
- (UIView *)tap_headerView;
- (BOOL)tap_isEnabledByDefault;
@end
