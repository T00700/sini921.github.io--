#import <Foundation/Foundation.h>
#import <MobileCoreServices/LSApplicationProxy.h>
#import "TAPApp.h"

@interface TAPAppList : NSObject {
    NSArray *_cachedAppList;
    NSString *_cachedAppListFile;
    NSArray<NSString *> *_blacklistedIdentifiers;
}

+(instancetype)shared;
-(NSArray<TAPApp *> *)getAllApps;
-(NSArray<TAPApp *> *)getAllApps:(BOOL)refresh;
-(NSArray<TAPApp *> *)getVisibleApps;
-(BOOL)isBlacklisted:(NSString *)identifier;
-(NSArray<NSString *> *)blacklistedIdentifiers;
-(void)setBlacklistedIdentifiers:(NSArray<NSString *> *)identifiers;
-(void)refreshAppListInBackgroundThread;

@end
