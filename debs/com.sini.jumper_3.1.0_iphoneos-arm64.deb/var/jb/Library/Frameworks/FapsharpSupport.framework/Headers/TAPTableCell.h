#import <Preferences/PSTableCell.h>
#import "TAPCell.h"

@interface PSTableCell (TAPTableCell)
@property (nonatomic, readonly) id<TAPCellProvider> provider;
- (void)setDetailTextLabelForSpecifier;
- (id<TAPCellProvider>)provider;
@end

@interface TAPTableCell : PSTableCell
@end
