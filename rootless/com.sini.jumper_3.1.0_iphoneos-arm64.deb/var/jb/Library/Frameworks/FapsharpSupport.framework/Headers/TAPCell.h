#import <Preferences/PSControlTableCell.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>


@protocol TAPLocalizableCellProvider <NSObject>
@optional
- (NSString *)localizedKeyFor:(NSString *)key;
@end

@protocol TAPCellProvider <TAPLocalizableCellProvider>
@optional
- (id)swipeActionsForCell:(id)cell;
- (id)tap_tintColor;
@end

@protocol TAPSelectorCellProvider <TAPCellProvider>
- (UIMenu *)menuForCell:(id)cell;
- (NSString *)title;
- (void)sendPrefsChangedNotification;

@optional
- (NSArray<UIAlertAction *>*)actionsForCell:(id)cell;
@end

@interface TAPStepperCell : PSControlTableCell {
    id<TAPCellProvider> _provider;
}
@property (nonatomic, retain) UIStepper *control;
- (void)reloadSpecifierWithAnimation:(BOOL)animated;
- (void)reloadSpecifiers;
@end

@interface TAPStepperCell (TAPSupport)
// TODO: Move to base interface
- (PSListController *)_viewControllerForAncestor;
@end

@interface TAPSelectorCell : PSControlTableCell {
    id<TAPSelectorCellProvider> _provider;
}
@property (nonatomic, retain) UIButton *control;
- (void)_updateControl;
- (void)reloadSpecifierWithAnimation:(BOOL)animated;
- (void)reloadSpecifiers;
@end

@interface TAPSelectorCell (TAPSupport)
- (PSListController *)_viewControllerForAncestor;
@end
