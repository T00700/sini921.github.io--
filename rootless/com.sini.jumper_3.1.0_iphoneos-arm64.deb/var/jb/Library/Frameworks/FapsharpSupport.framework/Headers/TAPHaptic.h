#import <AudioToolbox/AudioServices.h>
#import <UIKit/UIKit.h>

@interface TAPHaptic : NSObject
+ (void)fire;
@end
