#import <Foundation/Foundation.h>

@interface TAPSupport : NSObject {
    BOOL _preheated;
}

+ (instancetype)shared;
+ (instancetype)new UNAVAILABLE_ATTRIBUTE;
- (instancetype)init UNAVAILABLE_ATTRIBUTE;
- (void)preheatInBackground;
@end
