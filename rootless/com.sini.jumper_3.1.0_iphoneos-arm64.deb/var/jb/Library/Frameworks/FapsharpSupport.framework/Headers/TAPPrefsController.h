#import <Preferences/PSListController.h>
#import <Preferences/PSTableCell.h>
#import "TAPSwitch.h"

@interface PSTableCell (TAPSupport)
- (NSArray<UIContextualAction *> *)swipeActionsForRowAtIndexPath:(NSIndexPath *)indexPath;
@end

@interface NSUserDefaults (TAPSupport)
- (id)objectForKey:(NSString *)key inDomain:(NSString *)domain;
- (void)setObject:(id)value forKey:(NSString *)key inDomain:(NSString *)domain;
@end

@interface UINavigationItem (TAPSupport)
@property (assign, nonatomic) UINavigationBar *navigationBar;
@end

@interface TAPPrefsController: PSListController {
    UITableView *_table;
}
@property (nonatomic, strong) TAPSwitch *enableSwitch;
- (void)setEnableSwitchState;
- (void)switchStateChanged:(TAPSwitchState)state;
@end

@interface TAPPrefsController (Private) <TAPSwitchDelegate>
- (NSString *)_domain;
- (void)_showUIAlertButtonMenu;
- (void)_setupRightNavigationButtonMenu;
- (NSString*)_localizedKey:(NSString*)key file:(NSString *)fileName;
- (TAPSwitch *)_setUpEnableSwitch;
@end
