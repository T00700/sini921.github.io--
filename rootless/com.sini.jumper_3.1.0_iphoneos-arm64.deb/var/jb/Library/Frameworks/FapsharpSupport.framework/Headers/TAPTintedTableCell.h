#import "TAPCell.h"
#import "TAPTableCell.h"

@interface TAPTintedTableCell : TAPTableCell
@end
