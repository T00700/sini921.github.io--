#import <MobileCoreServices/LSApplicationProxy.h>
#import <MobileCoreServices/LSApplicationWorkspace.h>

@interface LSApplicationProxy (TAPAppList)
- (BOOL)tap_isSystemApplication;
- (BOOL)tap_isUserApplication;
- (BOOL)tap_isHidden;
- (NSString*)tap_fastDisplayName;
- (NSString*)tap_nameToDisplay;
@property (nonatomic,readonly) NSString* tap_bundleIdentifier;
@end

@interface LSApplicationWorkspace (TAPAppList)
- (NSArray*)tap_allInstalledApplications;
@end
