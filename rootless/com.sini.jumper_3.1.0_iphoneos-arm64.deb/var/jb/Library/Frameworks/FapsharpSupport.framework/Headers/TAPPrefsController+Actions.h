#import "TAPPrefsController.h"

@interface TAPPrefsController (Actions)
- (void)tap_respring;
- (void)tap_reset;
- (void)tap_openURL:(PSSpecifier *)specifier;
@end
