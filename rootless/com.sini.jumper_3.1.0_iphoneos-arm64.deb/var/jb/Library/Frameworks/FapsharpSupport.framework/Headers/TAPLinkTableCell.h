#import "TAPTintedTableCell.h"

@interface TAPLinkTableCell : TAPTintedTableCell
@end
