#include <spawn.h>
#import <UIKit/UIKit.h>

@interface FBSSystemService : NSObject
+ (id)sharedService;
- (void)sendActions:(id)arg1 withResult:(id)arg2;
@end

@interface BSAction : NSObject
@end

@interface SBSRelaunchAction : BSAction
+ (id)actionWithReason:(id)arg1 options:(unsigned long long)arg2 targetURL:(id)arg3;
@end

@interface TAPHelper: NSObject
+ (void)respringDevice;
+ (UIColor *)r:(int)r g:(int)g b:(int)b;
+ (UIColor *)r:(int)r g:(int)g b:(int)b a:(int)a;
+ (NSString *)getPackageVersion:(NSString *)packageName;
+ (NSString*)localizedKey:(NSString*)key usingFile:(NSString *)fileName inBundle:(NSBundle *)bundle;
+ (void)openURL:(NSURL *)url;
@end
