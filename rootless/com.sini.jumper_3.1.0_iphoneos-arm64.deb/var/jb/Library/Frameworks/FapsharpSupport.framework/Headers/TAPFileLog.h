#import <Foundation/Foundation.h>
#import "TAPMacros.h"

static void TAPFileLog(NSString *format, ...) {
    #ifndef DEBUG
        return;
    #endif

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:[NSDate date]];

    va_list args;
    va_start(args, format);
    NSString *message = [NSString stringWithFormat:@"[%@] %@\n", dateString, [[NSString alloc] initWithFormat:format arguments:args]];
    va_end(args);

    NSString *logPath = kTAPDocumentsDirectoryWithFile(@"tapsharpSupport.log");
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForUpdatingAtPath:logPath];
    if (fileHandle == nil) {
        [[NSFileManager defaultManager] createFileAtPath:logPath contents:nil attributes:nil];
        fileHandle = [NSFileHandle fileHandleForUpdatingAtPath:logPath];
    }
    [fileHandle seekToEndOfFile];
    [fileHandle writeData:[message dataUsingEncoding:NSUTF8StringEncoding]];
    [fileHandle closeFile];
}
