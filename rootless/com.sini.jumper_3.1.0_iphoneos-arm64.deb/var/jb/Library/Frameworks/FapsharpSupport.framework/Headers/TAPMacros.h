#import "TAPRootless.h"

// File paths
#define kTAPDocumentsDirectory ROOT_DIR_PATH_NS([NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0])
#define kTAPDocumentsDirectoryWithFile(file) [kTAPDocumentsDirectory stringByAppendingPathComponent:file]

// Notifications
#define kTAPInstalledAppsDidChangeNotification @"SBInstalledApplicationsDidChangeNotification"
