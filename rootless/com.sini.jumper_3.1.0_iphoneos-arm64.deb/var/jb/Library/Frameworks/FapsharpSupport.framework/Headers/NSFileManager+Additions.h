#import <Foundation/Foundation.h>

@interface NSFileManager (Addition)
- (BOOL)directoryExistsAtPath:(NSString *)path;
@end
