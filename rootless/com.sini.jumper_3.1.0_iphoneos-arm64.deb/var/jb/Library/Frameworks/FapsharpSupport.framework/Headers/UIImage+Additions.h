#import <UIKit/UIKit.h>

@interface UIImage (Additions)

+ (UIImage *)imageWithImage:(UIImage *)image convertToSize:(CGSize)size;

@end
