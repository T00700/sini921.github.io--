#import "TAPTintedTableCell.h"

@interface TAPLinkListTableCell: TAPTintedTableCell
@end
