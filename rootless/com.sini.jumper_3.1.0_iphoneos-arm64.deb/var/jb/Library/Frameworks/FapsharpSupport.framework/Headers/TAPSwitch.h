#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

#define kTAP_LIGHT_TINT [UIColor colorWithRed: 0.20 green: 0.60 blue: 0.86 alpha: 1.00]
#define kTAP_DARK_TINT [UIColor colorWithRed: 0.36 green: 0.68 blue: 0.89 alpha: 1.00]

typedef enum {
    TAPSwitchStyleLight,
    TAPSwitchStyleDark,
    TAPSwitchStyleDefault
} TAPSwitchStyle;

typedef enum {
    TAPSwitchStateOn,
    TAPSwitchStateOff
} TAPSwitchState;

typedef enum {
    TAPSwitchSizeBig,
    TAPSwitchSizeNormal,
    TAPSwitchSizeSmall
} TAPSwitchSize;

@protocol TAPSwitchDelegate <NSObject>
- (void)switchStateChanged:(TAPSwitchState)currentState;
@end

@interface TAPSwitch : UIControl
@property (nonatomic, assign) id<TAPSwitchDelegate> delegate;
@property (nonatomic, assign) BOOL isOn;
@property (nonatomic, assign) BOOL isEnabled;
@property (nonatomic, strong) UIColor *thumbOnTintColor;
@property (nonatomic, strong) UIColor *thumbOffTintColor;
@property (nonatomic, strong) UIColor *trackOnTintColor;
@property (nonatomic, strong) UIColor *trackOffTintColor;
@property (nonatomic, strong) UIColor *thumbDisabledTintColor;
@property (nonatomic, strong) UIColor *trackDisabledTintColor;
@property (nonatomic, strong) UIButton *switchThumb;
@property (nonatomic, strong) UIView *track;
- (id)init;
- (id)initWithSize:(TAPSwitchSize)size state:(TAPSwitchState)state;
- (id)initWithSize:(TAPSwitchSize)size style:(TAPSwitchStyle)style state:(TAPSwitchState)state;
- (BOOL)getSwitchState;
- (void)setOn:(BOOL)on;
- (void)setOn:(BOOL)on animated:(BOOL)animated;
- (void)setThumbState:(BOOL)state animated:(BOOL)animated;
@end
