#import <Preferences/PSSwitchTableCell.h>
#import <UIKit/UIKit.h>
#import "TAPTableCell.h"
#import "TAPSwitch.h"

@interface PSSwitchTableCell ()
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(id)identifier specifier:(id)specifier;
@end

@interface TAPSwitchCell : PSSwitchTableCell <TAPSwitchDelegate, UIColorPickerViewControllerDelegate>
@end
